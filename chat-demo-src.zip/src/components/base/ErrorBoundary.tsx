import { Component, type ErrorInfo, type ReactNode } from 'react'
import { translate } from '../../i18n/index.js'

type Props = { children: ReactNode }
type State = { message: string | null }

/** 渲染异常兜底：显示错误摘要与重新加载按钮，避免整页白屏或直接闪退 */
export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props)
    this.state = { message: null }
  }

  static getDerivedStateFromError(error: unknown): State {
    return { message: error instanceof Error ? error.message : String(error) }
  }

  override componentDidCatch(error: unknown, info: ErrorInfo): void {
    // eslint-disable-next-line no-console
    console.error('[app] render error', error, info.componentStack)
  }

  override render(): ReactNode {
    if (this.state.message === null) {
      return this.props.children
    }
    return (
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          minHeight: '100vh',
          padding: 24,
          background: 'var(--dsw-alias-bg-base, #ffffff)',
          color: 'var(--dsw-alias-label-primary, #111111)',
        }}
      >
        <div style={{ maxWidth: 420, width: '100%', textAlign: 'center' }}>
          <div style={{ fontSize: 16, fontWeight: 600 }}>{translate('crashTitle')}</div>
          <div
            style={{
              marginTop: 8,
              fontSize: 12,
              lineHeight: 1.6,
              opacity: 0.7,
              wordBreak: 'break-all',
            }}
          >
            {this.state.message}
          </div>
          <button
            type="button"
            onClick={() => window.location.reload()}
            style={{
              marginTop: 18,
              padding: '8px 20px',
              borderRadius: 100,
              border: '1px solid rgba(128, 128, 128, 0.35)',
              background: 'transparent',
              color: 'inherit',
              fontSize: 14,
              cursor: 'pointer',
            }}
          >
            {translate('crashReload')}
          </button>
        </div>
      </div>
    )
  }
}
