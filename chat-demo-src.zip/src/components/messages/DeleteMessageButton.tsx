import { useState } from 'react'
import { useTranslate } from '../../i18n/index.js'
import { deleteMessage } from '../../services/chat/store.js'
import { Button } from '../base/Button.js'
import { IconButton } from '../base/IconButton.js'
import { IconTrashOutline16 } from '../base/icons.js'
import { Modal } from '../base/Modal.js'
import { showToast } from '../base/toastState.js'

/** 删除单条消息：确认后连同它之后的分支内容一起删除。 */
export const DeleteMessageButton = ({
  sessionId,
  messageId,
  disabled = false,
}: {
  sessionId: string
  messageId: string
  disabled?: boolean
}) => {
  const t = useTranslate()
  const [open, setOpen] = useState(false)

  const remove = () => {
    setOpen(false)
    if (!deleteMessage(sessionId, messageId)) {
      showToast({ key: 'messageDeleteFailed', type: 'error' })
    }
  }

  return (
    <>
      <IconButton
        icon={<IconTrashOutline16 />}
        tooltip={t('deleteMessage')}
        tooltipPlacement="bottom"
        disabled={disabled}
        onClick={() => setOpen(true)}
      />
      {open ? (
        <Modal
          title={t('deleteMessageModalTitle')}
          onClose={() => setOpen(false)}
          footer={
            <>
              <Button variant="outlined" onClick={() => setOpen(false)}>
                {t('cancel')}
              </Button>
              <Button variant="danger" onClick={remove}>
                {t('delete')}
              </Button>
            </>
          }
        >
          {t('deleteMessageDescription')}
        </Modal>
      ) : null}
    </>
  )
}
