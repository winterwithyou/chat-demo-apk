import { useState } from 'react'
import { useTranslate } from '../../i18n/index.js'
import { deleteMessages } from '../../services/chat/store.js'
import type { Message } from '../../services/chat/types.js'
import { Button } from '../base/Button.js'
import { showToast } from '../base/toastState.js'

/** 一次渲染的行数；几千轮对话时避免一次性创建过多节点 */
const PAGE_SIZE = 500

/** 单行预览：取纯文本，压掉换行，截断 */
const previewText = (message: Message): string => {
  const text =
    message.role === 'user'
      ? message.content
      : message.blocks
          .map((block) => (block.type === 'text' ? block.text : ''))
          .filter(Boolean)
          .join(' ')
  return text.replace(/\s+/g, ' ').trim().slice(0, 80)
}

const clock = (time: number): string => {
  const date = new Date(time)
  return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
}

/**
 * 消息多选清单：只渲染纯文本行，不加载 Markdown/公式/图表，
 * 因此几千轮的对话也能安全打开、勾选并批量删除。
 */
export const MessagePicker = ({
  sessionId,
  messages,
  onClose,
}: {
  sessionId: string
  messages: Message[]
  onClose: () => void
}) => {
  const t = useTranslate()
  const [selected, setSelected] = useState<ReadonlySet<string>>(() => new Set<string>())
  const [limit, setLimit] = useState(PAGE_SIZE)
  const [confirming, setConfirming] = useState(false)

  const allSelected = messages.length > 0 && messages.every((message) => selected.has(message.id))
  const shown = messages.slice(0, limit)

  const toggle = (id: string) => {
    setSelected((current) => {
      const next = new Set(current)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }

  const toggleAll = () => {
    setSelected(allSelected ? new Set<string>() : new Set(messages.map((message) => message.id)))
  }

  const remove = () => {
    const ids = [...selected]
    if (deleteMessages(sessionId, ids)) {
      onClose()
      return
    }
    onClose()
    showToast({ key: 'messagesDeleteFailed', type: 'error' })
  }

  const checkboxStyle = (picked: boolean) => ({
    flex: '0 0 auto' as const,
    width: 20,
    height: 20,
    borderRadius: 10,
    border: '1px solid rgba(128, 128, 128, 0.5)',
    background: picked ? '#4d6bfe' : 'transparent',
    color: '#fff',
    fontSize: 11,
    lineHeight: '18px',
    textAlign: 'center' as const,
    cursor: 'pointer',
    padding: 0,
  })

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 900,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 12,
        background: 'rgba(0, 0, 0, 0.45)',
      }}
      onClick={(event) => {
        if (event.target === event.currentTarget) {
          onClose()
        }
      }}
    >
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          width: '100%',
          maxWidth: 520,
          maxHeight: '86vh',
          borderRadius: 14,
          background: 'var(--dsw-alias-bg-base, #ffffff)',
          color: 'var(--dsw-alias-label-primary, #111111)',
          boxShadow: '0 12px 32px rgba(0, 0, 0, 0.24)',
          overflow: 'hidden',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            padding: '12px 14px',
            borderBottom: '1px solid rgba(128, 128, 128, 0.2)',
          }}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2, minWidth: 0 }}>
            <strong style={{ fontSize: 14 }}>{t('messagePickerTitle')}</strong>
            <span style={{ fontSize: 11, opacity: 0.6 }}>{t('messagePickerHint')}</span>
          </div>
          <span style={{ flex: 1 }} />
          <button type="button" onClick={toggleAll} style={checkboxStyle(allSelected)}>
            {allSelected ? '✓' : ''}
          </button>
          <span style={{ fontSize: 12, opacity: 0.75 }}>{t('selectAll')}</span>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: '2px 8px' }}>
          {shown.map((message) => {
            const picked = selected.has(message.id)
            return (
              <div
                key={message.id}
                onClick={() => toggle(message.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '7px 6px',
                  borderBottom: '1px solid rgba(128, 128, 128, 0.14)',
                  cursor: 'pointer',
                }}
              >
                <button
                  type="button"
                  aria-label={t('selectMessages')}
                  onClick={(event) => {
                    event.stopPropagation()
                    toggle(message.id)
                  }}
                  style={checkboxStyle(picked)}
                >
                  {picked ? '✓' : ''}
                </button>
                <span
                  style={{
                    flex: '0 0 auto',
                    fontSize: 11,
                    opacity: 0.6,
                    width: 54,
                  }}
                >
                  {message.role === 'user' ? t('exportRoleUser') : t('exportRoleAssistant')}
                </span>
                <span
                  style={{
                    flex: 1,
                    minWidth: 0,
                    fontSize: 12,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {previewText(message) || '…'}
                </span>
                <span style={{ flex: '0 0 auto', fontSize: 11, opacity: 0.45 }}>
                  {clock(message.createdAt)}
                </span>
              </div>
            )
          })}
          {limit < messages.length ? (
            <div style={{ padding: '10px 0', textAlign: 'center' }}>
              <Button size="s" variant="outlined" onClick={() => setLimit(limit + PAGE_SIZE)}>
                {t('messagePickerLoadMore')}
              </Button>
            </div>
          ) : null}
        </div>

        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            padding: '10px 14px',
            borderTop: '1px solid rgba(128, 128, 128, 0.2)',
          }}
        >
          <span style={{ flex: 1, fontSize: 12, opacity: 0.75 }}>
            {confirming
              ? t('messagePickerConfirm', { count: selected.size })
              : t('selectedMessagesCount', { count: selected.size })}
          </span>
          {confirming ? (
            <>
              <Button size="s" variant="outlined" onClick={() => setConfirming(false)}>
                {t('cancel')}
              </Button>
              <Button size="s" variant="danger" onClick={remove}>
                {t('delete')}
              </Button>
            </>
          ) : (
            <>
              <Button size="s" variant="outlined" onClick={onClose}>
                {t('cancel')}
              </Button>
              <Button
                size="s"
                variant="danger"
                disabled={selected.size === 0}
                onClick={() => setConfirming(true)}
              >
                {t('delete')}
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
