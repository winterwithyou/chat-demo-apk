import { useMemo, useState } from 'react'
import { useTranslate } from '../../i18n/index.js'
import { deleteMessages } from '../../services/chat/store.js'
import type { Message } from '../../services/chat/types.js'
import { Button } from '../base/Button.js'
import styles from './MessagePicker.module.css'

/** 一次渲染的轮数；几千轮的对话也只会渲染这么多行 */
const PAGE_SIZE = 100

/** 单行预览：取纯文本，压掉换行，截断 */
const previewText = (message: Message): string => {
  const text =
    message.role === 'user'
      ? message.content
      : message.blocks
          .map((block) => (block.type === 'text' ? block.text : ''))
          .filter(Boolean)
          .join(' ')
  return text.replace(/\s+/g, ' ').trim().slice(0, 80)
}

/** 一轮对话：提问 + 它的回答预览（成对删除的最小单位） */
type Round = {
  id: string
  time: number
  question: string
  answer: string
}

const buildRounds = (messages: Message[]): Round[] => {
  const rounds: Round[] = []
  let current: Round | null = null
  for (const message of messages) {
    if (message.role === 'user') {
      if (current) {
        rounds.push(current)
      }
      current = {
        id: message.id,
        time: message.createdAt,
        question: previewText(message),
        answer: '',
      }
      continue
    }
    if (!current) {
      continue
    }
    const text = previewText(message)
    current.answer = current.answer ? `${current.answer} ${text}` : text
  }
  if (current) {
    rounds.push(current)
  }
  return rounds
}

const clock = (time: number): string => {
  const date = new Date(time)
  return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
}

/**
 * 消息多选清单：每轮一行、最新的在最上面，只渲染纯文本，不加载 Markdown/公式/图表。
 * 配合分页与 content-visibility，几千轮的对话也能安全滚动、勾选和批量删除。
 */
export const MessagePicker = ({
  sessionId,
  messages,
  onClose,
}: {
  sessionId: string
  messages: Message[]
  onClose: () => void
}) => {
  const t = useTranslate()
  const [selected, setSelected] = useState<ReadonlySet<string>>(() => new Set<string>())
  const [limit, setLimit] = useState(PAGE_SIZE)
  const [confirming, setConfirming] = useState(false)
  /** 删除失败的原因；就地显示在底部，避免弹窗关掉后看不到提示 */
  const [error, setError] = useState<string | null>(null)

  /** 最新的在最前，方便「全选 → 取消最近几条 → 删旧的」 */
  const rounds = useMemo(() => buildRounds(messages).reverse(), [messages])
  const shown = useMemo(() => rounds.slice(0, limit), [rounds, limit])
  const allSelected = rounds.length > 0 && rounds.every((round) => selected.has(round.id))

  const toggle = (id: string) => {
    setError(null)
    setSelected((current) => {
      const next = new Set(current)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }

  const toggleAll = () => {
    setError(null)
    setSelected(allSelected ? new Set<string>() : new Set(rounds.map((round) => round.id)))
  }

  const remove = () => {
    const result = deleteMessages(sessionId, [...selected])
    if (result === 'ok') {
      onClose()
      return
    }
    setError(
      result === 'busy'
        ? t('messageDeleteBusy')
        : result === 'stale'
          ? t('messageDeleteStale')
          : t('messageDeleteEmpty')
    )
    setConfirming(false)
  }

  const checkboxStyle = (picked: boolean) => ({
    flex: '0 0 auto' as const,
    width: 20,
    height: 20,
    borderRadius: 10,
    border: '1px solid rgba(128, 128, 128, 0.5)',
    background: picked ? '#4d6bfe' : 'transparent',
    color: '#fff',
    fontSize: 11,
    lineHeight: '18px',
    textAlign: 'center' as const,
    cursor: 'pointer',
    padding: 0,
  })

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 900,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 12,
        background: 'rgba(0, 0, 0, 0.45)',
      }}
      onClick={(event) => {
        if (event.target === event.currentTarget) {
          onClose()
        }
      }}
    >
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          width: '100%',
          maxWidth: 520,
          maxHeight: '86vh',
          borderRadius: 14,
          background: 'var(--dsw-alias-bg-base, #ffffff)',
          color: 'var(--dsw-alias-label-primary, #111111)',
          boxShadow: '0 12px 32px rgba(0, 0, 0, 0.24)',
          overflow: 'hidden',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            padding: '12px 14px',
            borderBottom: '1px solid rgba(128, 128, 128, 0.2)',
          }}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2, minWidth: 0 }}>
            <strong style={{ fontSize: 14 }}>{t('messagePickerTitle')}</strong>
            <span style={{ fontSize: 11, opacity: 0.6 }}>{t('messagePickerHint')}</span>
          </div>
          <span style={{ flex: 1 }} />
          <button type="button" onClick={toggleAll} style={checkboxStyle(allSelected)}>
            {allSelected ? '✓' : ''}
          </button>
          <span style={{ fontSize: 12, opacity: 0.75 }}>{t('selectAll')}</span>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: '2px 8px' }}>
          {shown.map((round) => {
            const picked = selected.has(round.id)
            return (
              <div
                key={round.id}
                className={styles.row}
                onClick={() => toggle(round.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '6px 6px',
                  borderBottom: '1px solid rgba(128, 128, 128, 0.14)',
                  cursor: 'pointer',
                }}
              >
                <button
                  type="button"
                  aria-label={t('selectMessages')}
                  onClick={(event) => {
                    event.stopPropagation()
                    toggle(round.id)
                  }}
                  style={checkboxStyle(picked)}
                >
                  {picked ? '✓' : ''}
                </button>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontSize: 12,
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {round.question || '…'}
                  </div>
                  <div
                    style={{
                      fontSize: 11,
                      opacity: 0.55,
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {round.answer || '…'}
                  </div>
                </div>
                <span style={{ flex: '0 0 auto', fontSize: 11, opacity: 0.45 }}>
                  {clock(round.time)}
                </span>
              </div>
            )
          })}
          {limit < rounds.length ? (
            <div style={{ padding: '10px 0', textAlign: 'center' }}>
              <Button size="s" variant="outlined" onClick={() => setLimit(limit + PAGE_SIZE)}>
                {t('messagePickerLoadMore')}
              </Button>
            </div>
          ) : null}
        </div>

        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            padding: '10px 14px',
            borderTop: '1px solid rgba(128, 128, 128, 0.2)',
          }}
        >
          <span
            style={{
              flex: 1,
              fontSize: 12,
              opacity: error ? 1 : 0.75,
              color: error ? '#e5484d' : 'inherit',
            }}
          >
            {error
              ? error
              : confirming
                ? t('messagePickerConfirm')
                : t('selectedRoundsCount', { count: selected.size })}
          </span>
          {confirming ? (
            <>
              <Button size="s" variant="outlined" onClick={() => setConfirming(false)}>
                {t('cancel')}
              </Button>
              <Button size="s" variant="danger" onClick={remove}>
                {t('delete')}
              </Button>
            </>
          ) : (
            <>
              <Button size="s" variant="outlined" onClick={onClose}>
                {t('cancel')}
              </Button>
              <Button
                size="s"
                variant="danger"
                disabled={selected.size === 0}
                onClick={() => setConfirming(true)}
              >
                {t('delete')}
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
