import { create } from 'zustand'

/** 对话内的消息多选：进入后每条消息左侧显示勾选框，底部出现批量删除。 */
type MessageSelection = {
  selecting: boolean
  selected: ReadonlySet<string>
}

export const useMessageSelection = create<MessageSelection>(() => ({
  selecting: false,
  selected: new Set<string>(),
}))

export const enterMessageSelection = () =>
  useMessageSelection.setState({ selecting: true, selected: new Set<string>() })

export const exitMessageSelection = () =>
  useMessageSelection.setState({ selecting: false, selected: new Set<string>() })

export const toggleMessageSelection = (id: string) =>
  useMessageSelection.setState((state) => {
    const next = new Set(state.selected)
    if (next.has(id)) {
      next.delete(id)
    } else {
      next.add(id)
    }
    return { selected: next }
  })

/** 全选当前对话里可见的消息。 */
export const selectAllMessages = (ids: readonly string[]) =>
  useMessageSelection.setState({ selected: new Set(ids) })

/** 取消全部勾选，但停留在多选模式。 */
export const clearMessageSelection = () =>
  useMessageSelection.setState({ selected: new Set<string>() })
