import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { useIsMobile } from '../../app/viewport.js'
import {
  buildMessageVersions,
  getVisibleMessages,
  type MessageVersions,
} from '../../services/chat/branches.js'
import { selectMessageVersion } from '../../services/chat/store.js'
import type { Session } from '../../services/chat/types.js'
import { useTranslate } from '../../i18n/index.js'
import { Button } from '../base/Button.js'
import { closeSearchPanel } from '../search/searchPanelState.js'
import { MessagePicker } from './MessagePicker.js'
import { AssistantMessage } from './AssistantMessage.js'
import { ScrollToBottomContext } from './scrollContext.js'
import { UserMessage } from './UserMessage.js'
import type { Message } from '../../services/chat/types.js'

/**
 * 会话共用可重试的附件上传失败入口，覆盖当前提问与历史消息中的附件。
 * 点击后按失败的回答重新补传附件并请求。
 */
const getUploadRetryId = (messages: Message[], streaming: boolean) => {
  const last = messages.at(-1)
  return !streaming &&
    last?.role === 'assistant' &&
    last.status === 'error' &&
    last.error?.kind === 'upload' &&
    last.error.retryable
    ? last.id
    : null
}
import styles from './MessageList.module.css'

/** 距底部小于该值时视为在底部，流式内容增长时跟随 */
const STICKY_THRESHOLD = 40
/** 内容超出可视区这么多才显示悬浮回顶/到底按钮 */
const JUMPER_THRESHOLD = 80
/** 窗口化渲染：初始只挂载最近这么多条，向上滚动再按批补，DOM 总量有上限 */
const WINDOW_INITIAL = 60
const WINDOW_STEP = 40
const WINDOW_LIMIT = 400
const EMPTY_VERSIONS: MessageVersions = { ids: [], index: -1 }

export const MessageList = ({
  session,
  streaming,
  footer,
}: {
  session: Session
  streaming: boolean
  footer: React.ReactNode
}) => {
  const t = useTranslate()
  const isMobile = useIsMobile()
  /** 消息多选清单开关：清单只渲染纯文本行，几千轮对话也能安全打开 */
  const [pickerOpen, setPickerOpen] = useState(false)
  const [overflowing, setOverflowing] = useState(false)
  /** 当前是否停在底部：决定悬浮球是「回顶部」还是「到底部」 */
  const [atBottom, setAtBottom] = useState(true)
  const scrollRef = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)
  const stickyRef = useRef(true)
  const scrollTopRef = useRef(0)
  const restoreScrollRef = useRef<{ messageId: string; top: number } | null>(null)
  /** 已挂载的消息条数；数据本身始终完整，只影响渲染 */
  const [windowSize, setWindowSize] = useState(WINDOW_INITIAL)
  /** 向上补历史时的滚动锚点：滚动高度 - 视口顶部，用于插入后保持视觉位置 */
  const prependAnchorRef = useRef<number | null>(null)
  const loadEarlierRef = useRef<() => void>(() => {})
  const messages = getVisibleMessages(session)
  const start = Math.max(0, messages.length - windowSize)
  const rendered = start > 0 ? messages.slice(start) : messages
  const atWindowLimit = windowSize >= WINDOW_LIMIT
  /** 供滚动回调读取最新窗口状态，避免闭包过期 */
  const startRef = useRef(0)
  startRef.current = start
  const atLimitRef = useRef(false)
  atLimitRef.current = atWindowLimit
  const [previousVersions, setPreviousVersions] = useState(() =>
    buildMessageVersions(session, new Map())
  )
  const versions = useMemo(
    () => buildMessageVersions(session, previousVersions),
    [session, previousVersions]
  )
  if (versions !== previousVersions) {
    setPreviousVersions(versions)
  }
  const lastMessageId = messages.at(-1)?.id
  const scrollToBottom = useCallback(() => {
    const el = scrollRef.current
    if (el && stickyRef.current) {
      el.scrollTop = el.scrollHeight
      scrollTopRef.current = el.scrollTop
    }
  }, [])

  // 内容、键盘和输入框高度变化时继续跟随底部，并同步刷新悬浮球的显示条件。
  // 长对话里的图片、公式、代码块会陆续撑开内容，只在初始布局算一次会导致悬浮球不出现。
  useLayoutEffect(() => {
    const content = contentRef.current
    const scroll = scrollRef.current
    if (!content || !scroll) {
      return
    }
    const syncOverflow = () => {
      const el = scrollRef.current
      if (el) {
        setOverflowing(el.scrollHeight - el.clientHeight > JUMPER_THRESHOLD)
      }
    }
    const observer = new ResizeObserver(() => {
      scrollToBottom()
      syncOverflow()
    })
    observer.observe(content)
    observer.observe(scroll)
    syncOverflow()
    return () => observer.disconnect()
  }, [isMobile, scrollToBottom])

  // 切换版本后将选择器留在原位置，避免回答长短变化导致操作区跳出视口。
  useLayoutEffect(() => {
    const anchor = restoreScrollRef.current
    const scroll = scrollRef.current
    if (anchor && scroll) {
      const switcher = scroll.querySelector<HTMLElement>(
        `[data-message-version="${CSS.escape(anchor.messageId)}"]`
      )
      if (switcher) {
        scroll.scrollTop += switcher.getBoundingClientRect().top - anchor.top
      }
      restoreScrollRef.current = null
      return
    }
    stickyRef.current = true
    scrollToBottom()
  }, [session.id, lastMessageId, scrollToBottom])

  useEffect(closeSearchPanel, [session.id, lastMessageId])

  // 切换会话时关闭多选清单并重置渲染窗口
  useEffect(() => {
    setPickerOpen(false)
    setWindowSize(WINDOW_INITIAL)
  }, [session.id])

  /** 向上补一批历史；插入前记录锚点，插入后补偿滚动位置，避免视口跳动 */
  const loadEarlier = useCallback(() => {
    if (windowSize >= WINDOW_LIMIT) {
      return
    }
    const el = scrollRef.current
    if (el) {
      prependAnchorRef.current = el.scrollHeight - el.scrollTop
    }
    setWindowSize((size) => Math.min(size + WINDOW_STEP, WINDOW_LIMIT))
  }, [windowSize])
  loadEarlierRef.current = loadEarlier

  useLayoutEffect(() => {
    const anchor = prependAnchorRef.current
    const el = scrollRef.current
    if (anchor !== null && el) {
      el.scrollTop = el.scrollHeight - anchor
      prependAnchorRef.current = null
    }
  }, [windowSize])

  const selectVersion = useCallback(
    (messageId: string, anchorTop: number) => {
      if (streaming) {
        return
      }
      restoreScrollRef.current = { messageId, top: anchorTop }
      stickyRef.current = false
      closeSearchPanel()
      selectMessageVersion(session.id, messageId)
    },
    [session.id, streaming]
  )

  // 跨移动端断点时切换滚动层，并保持输入框及当前阅读位置。
  useLayoutEffect(() => {
    const el = scrollRef.current
    if (!el) {
      return
    }
    if (stickyRef.current) {
      scrollToBottom()
    } else {
      el.scrollTop = scrollTopRef.current
    }
    const onScroll = () => {
      const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < STICKY_THRESHOLD
      // 仅在用户向上滚动时停止跟随底部，布局或内容增高时保持跟随状态。
      if (nearBottom) {
        stickyRef.current = true
      } else if (el.scrollTop < scrollTopRef.current) {
        stickyRef.current = false
      }
      scrollTopRef.current = el.scrollTop
      setAtBottom(nearBottom)
      setOverflowing(el.scrollHeight - el.clientHeight > JUMPER_THRESHOLD)
      // 滚到渲染窗口顶部时自动补一批更早的消息（窗口已到上限或没有更多时不做）
      if (el.scrollTop < 48 && startRef.current > 0 && !atLimitRef.current) {
        loadEarlierRef.current()
      }
    }
    onScroll()
    el.addEventListener('scroll', onScroll, { passive: true })
    return () => el.removeEventListener('scroll', onScroll)
  }, [isMobile, scrollToBottom])

  const lastIndex = messages.length - 1
  const jumpToTop = useCallback(() => {
    const el = scrollRef.current
    if (!el) {
      return
    }
    stickyRef.current = false
    el.scrollTop = 0
    scrollTopRef.current = 0
  }, [])

  const jumpToBottom = useCallback(() => {
    const el = scrollRef.current
    if (!el) {
      return
    }
    stickyRef.current = true
    el.scrollTop = el.scrollHeight
    scrollTopRef.current = el.scrollTop
  }, [])

  // 打开长对话或消息数量变化时刷新判断；延迟一帧等布局稳定后再算一次
  useEffect(() => {
    const timer = window.setTimeout(() => {
      const el = scrollRef.current
      if (el) {
        setOverflowing(el.scrollHeight - el.clientHeight > JUMPER_THRESHOLD)
      }
    }, 120)
    return () => window.clearTimeout(timer)
  }, [lastMessageId, session.id, messages.length])

  const uploadRetryId = getUploadRetryId(messages, streaming)
  return (
    <ScrollToBottomContext.Provider value={scrollToBottom}>
      <div ref={isMobile ? undefined : scrollRef} className={styles.container}>
        <div ref={isMobile ? scrollRef : undefined} className={styles.scroll}>
          <div ref={contentRef} className={styles.column}>
            {messages.length > 1 ? (
              <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '4px 0 10px' }}>
                <Button size="s" variant="outlined" onClick={() => setPickerOpen(true)}>
                  {t('selectMessages')}
                </Button>
              </div>
            ) : null}
            {start > 0 ? (
              <div
                style={{ display: 'flex', justifyContent: 'center', padding: '2px 0 12px' }}
              >
                <Button
                  size="s"
                  variant="outlined"
                  disabled={atWindowLimit}
                  onClick={loadEarlier}
                >
                  {atWindowLimit ? t('windowLimitHint') : t('loadEarlierMessages')}
                </Button>
              </div>
            ) : null}
            {rendered.map((message, offset) => {
              const index = start + offset
              const node =
                message.role === 'user' ? (
                  <UserMessage
                    key={message.id}
                    sessionId={session.id}
                    message={message}
                    retryUploadId={uploadRetryId}
                    isFirst={index === 0}
                    isLast={index === lastIndex || index === lastIndex - 1}
                    busy={streaming}
                    versions={versions.get(message.id) ?? EMPTY_VERSIONS}
                    onSelectVersion={selectVersion}
                  />
                ) : (
                  <AssistantMessage
                    key={message.id}
                    sessionId={session.id}
                    message={message}
                    isLast={index === lastIndex}
                    streaming={streaming && index === lastIndex}
                    busy={streaming}
                    versions={versions.get(message.id) ?? EMPTY_VERSIONS}
                    onSelectVersion={selectVersion}
                  />
                )
              return node
            })}
          </div>
        </div>
        {overflowing && !pickerOpen ? (
          <button
            type="button"
            aria-label={atBottom ? t('scrollToTop') : t('scrollToBottom')}
            onClick={atBottom ? jumpToTop : jumpToBottom}
            style={{
              position: 'fixed',
              left: 12,
              bottom: 150,
              zIndex: 20,
              width: 36,
              height: 36,
              borderRadius: 18,
              border: '1px solid rgba(128, 128, 128, 0.35)',
              background: 'rgba(128, 128, 128, 0.14)',
              color: 'inherit',
              fontSize: 16,
              lineHeight: '34px',
              cursor: 'pointer',
              padding: 0,
            }}
          >
            {atBottom ? '↑' : '↓'}
          </button>
        ) : null}
        {pickerOpen ? (
          <MessagePicker
            sessionId={session.id}
            messages={messages}
            onClose={() => setPickerOpen(false)}
          />
        ) : null}
        {footer}
      </div>
    </ScrollToBottomContext.Provider>
  )
}
