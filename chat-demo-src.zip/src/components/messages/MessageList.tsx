import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { useIsMobile } from '../../app/viewport.js'
import {
  buildMessageVersions,
  getVisibleMessages,
  type MessageVersions,
} from '../../services/chat/branches.js'
import { deleteMessages, selectMessageVersion } from '../../services/chat/store.js'
import type { Session } from '../../services/chat/types.js'
import { useTranslate } from '../../i18n/index.js'
import { Button } from '../base/Button.js'
import { Modal } from '../base/Modal.js'
import { showToast } from '../base/toastState.js'
import { closeSearchPanel } from '../search/searchPanelState.js'
import {
  clearMessageSelection,
  enterMessageSelection,
  exitMessageSelection,
  selectAllMessages,
  toggleMessageSelection,
  useMessageSelection,
} from './messageSelection.js'
import { AssistantMessage } from './AssistantMessage.js'
import { ScrollToBottomContext } from './scrollContext.js'
import { UserMessage } from './UserMessage.js'
import type { Message } from '../../services/chat/types.js'

/**
 * 会话共用可重试的附件上传失败入口，覆盖当前提问与历史消息中的附件。
 * 点击后按失败的回答重新补传附件并请求。
 */
const getUploadRetryId = (messages: Message[], streaming: boolean) => {
  const last = messages.at(-1)
  return !streaming &&
    last?.role === 'assistant' &&
    last.status === 'error' &&
    last.error?.kind === 'upload' &&
    last.error.retryable
    ? last.id
    : null
}
import styles from './MessageList.module.css'

/** 距底部小于该值时视为在底部，流式内容增长时跟随 */
const STICKY_THRESHOLD = 40
/** 内容超出可视区这么多才显示悬浮回顶/到底按钮 */
const JUMPER_THRESHOLD = 80
const EMPTY_VERSIONS: MessageVersions = { ids: [], index: -1 }

export const MessageList = ({
  session,
  streaming,
  footer,
}: {
  session: Session
  streaming: boolean
  footer: React.ReactNode
}) => {
  const t = useTranslate()
  const isMobile = useIsMobile()
  const selecting = useMessageSelection((state) => state.selecting)
  const selected = useMessageSelection((state) => state.selected)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [overflowing, setOverflowing] = useState(false)
  /** 当前是否停在底部：决定悬浮球是「回顶部」还是「到底部」 */
  const [atBottom, setAtBottom] = useState(true)
  const scrollRef = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)
  const stickyRef = useRef(true)
  const scrollTopRef = useRef(0)
  const restoreScrollRef = useRef<{ messageId: string; top: number } | null>(null)
  const messages = getVisibleMessages(session)
  const [previousVersions, setPreviousVersions] = useState(() =>
    buildMessageVersions(session, new Map())
  )
  const versions = useMemo(
    () => buildMessageVersions(session, previousVersions),
    [session, previousVersions]
  )
  if (versions !== previousVersions) {
    setPreviousVersions(versions)
  }
  const lastMessageId = messages.at(-1)?.id
  const scrollToBottom = useCallback(() => {
    const el = scrollRef.current
    if (el && stickyRef.current) {
      el.scrollTop = el.scrollHeight
      scrollTopRef.current = el.scrollTop
    }
  }, [])

  // 内容、键盘和输入框高度变化时，继续遵循当前跟随状态。
  useLayoutEffect(() => {
    const content = contentRef.current
    const scroll = scrollRef.current
    if (!content || !scroll) {
      return
    }
    const observer = new ResizeObserver(scrollToBottom)
    observer.observe(content)
    observer.observe(scroll)
    return () => observer.disconnect()
  }, [isMobile, scrollToBottom])

  // 切换版本后将选择器留在原位置，避免回答长短变化导致操作区跳出视口。
  useLayoutEffect(() => {
    const anchor = restoreScrollRef.current
    const scroll = scrollRef.current
    if (anchor && scroll) {
      const switcher = scroll.querySelector<HTMLElement>(
        `[data-message-version="${CSS.escape(anchor.messageId)}"]`
      )
      if (switcher) {
        scroll.scrollTop += switcher.getBoundingClientRect().top - anchor.top
      }
      restoreScrollRef.current = null
      return
    }
    stickyRef.current = true
    scrollToBottom()
  }, [session.id, lastMessageId, scrollToBottom])

  useEffect(closeSearchPanel, [session.id, lastMessageId])

  // 切换会话时退出多选，避免勾选状态串到别的对话
  useEffect(() => {
    exitMessageSelection()
  }, [session.id])

  const selectVersion = useCallback(
    (messageId: string, anchorTop: number) => {
      if (streaming) {
        return
      }
      restoreScrollRef.current = { messageId, top: anchorTop }
      stickyRef.current = false
      closeSearchPanel()
      selectMessageVersion(session.id, messageId)
    },
    [session.id, streaming]
  )

  // 跨移动端断点时切换滚动层，并保持输入框及当前阅读位置。
  useLayoutEffect(() => {
    const el = scrollRef.current
    if (!el) {
      return
    }
    if (stickyRef.current) {
      scrollToBottom()
    } else {
      el.scrollTop = scrollTopRef.current
    }
    const onScroll = () => {
      const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < STICKY_THRESHOLD
      // 仅在用户向上滚动时停止跟随底部，布局或内容增高时保持跟随状态。
      if (nearBottom) {
        stickyRef.current = true
      } else if (el.scrollTop < scrollTopRef.current) {
        stickyRef.current = false
      }
      scrollTopRef.current = el.scrollTop
      setAtBottom(nearBottom)
      setOverflowing(el.scrollHeight - el.clientHeight > JUMPER_THRESHOLD)
    }
    onScroll()
    el.addEventListener('scroll', onScroll, { passive: true })
    return () => el.removeEventListener('scroll', onScroll)
  }, [isMobile, scrollToBottom])

  const lastIndex = messages.length - 1
  const allSelected =
    messages.length > 0 && messages.every((message) => selected.has(message.id))
  const toggleAll = () => {
    if (allSelected) {
      clearMessageSelection()
    } else {
      selectAllMessages(messages.map((message) => message.id))
    }
  }
  const jumpToTop = useCallback(() => {
    const el = scrollRef.current
    if (!el) {
      return
    }
    stickyRef.current = false
    el.scrollTop = 0
    scrollTopRef.current = 0
  }, [])

  const jumpToBottom = useCallback(() => {
    const el = scrollRef.current
    if (!el) {
      return
    }
    stickyRef.current = true
    el.scrollTop = el.scrollHeight
    scrollTopRef.current = el.scrollTop
  }, [])

  // 打开长对话或消息数量变化时刷新判断，避免悬浮按钮要滚动一下才出现
  useEffect(() => {
    const el = scrollRef.current
    if (el) {
      setOverflowing(el.scrollHeight - el.clientHeight > JUMPER_THRESHOLD)
    }
  }, [lastMessageId, session.id])

  const uploadRetryId = getUploadRetryId(messages, streaming)
  return (
    <ScrollToBottomContext.Provider value={scrollToBottom}>
      <div ref={isMobile ? undefined : scrollRef} className={styles.container}>
        <div ref={isMobile ? scrollRef : undefined} className={styles.scroll}>
          <div ref={contentRef} className={styles.column}>
            {selecting ? (
              <div
                style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0 10px' }}
              >
                <button
                  type="button"
                  aria-label={t('selectAll')}
                  onClick={toggleAll}
                  style={{
                    flex: '0 0 auto',
                    width: 22,
                    height: 22,
                    borderRadius: 11,
                    border: '1px solid rgba(128, 128, 128, 0.5)',
                    background: allSelected ? '#4d6bfe' : 'transparent',
                    color: '#fff',
                    fontSize: 12,
                    lineHeight: '20px',
                    cursor: 'pointer',
                  }}
                >
                  {allSelected ? '✓' : ''}
                </button>
                <span style={{ fontSize: 12, opacity: 0.8 }}>{t('selectAll')}</span>
                <span style={{ flex: 1 }} />
                <span style={{ fontSize: 12, opacity: 0.8 }}>
                  {t('selectedMessagesCount', { count: selected.size })}
                </span>
              </div>
            ) : messages.length > 1 ? (
              <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '4px 0 10px' }}>
                <Button size="s" variant="outlined" onClick={enterMessageSelection}>
                  {t('selectMessages')}
                </Button>
              </div>
            ) : null}
            {messages.map((message, index) => {
              const node =
                message.role === 'user' ? (
                  <UserMessage
                    key={message.id}
                    sessionId={session.id}
                    message={message}
                    retryUploadId={uploadRetryId}
                    isFirst={index === 0}
                    isLast={index === lastIndex || index === lastIndex - 1}
                    busy={streaming}
                    versions={versions.get(message.id) ?? EMPTY_VERSIONS}
                    onSelectVersion={selectVersion}
                  />
                ) : (
                  <AssistantMessage
                    key={message.id}
                    sessionId={session.id}
                    message={message}
                    isLast={index === lastIndex}
                    streaming={streaming && index === lastIndex}
                    busy={streaming}
                    versions={versions.get(message.id) ?? EMPTY_VERSIONS}
                    onSelectVersion={selectVersion}
                  />
                )
              if (!selecting) {
                return node
              }
              const picked = selected.has(message.id)
              return (
                <div
                  key={message.id}
                  style={{ display: 'flex', alignItems: 'flex-start', gap: 8 }}
                >
                  <button
                    type="button"
                    aria-label={t('selectMessages')}
                    onClick={() => toggleMessageSelection(message.id)}
                    style={{
                      flex: '0 0 auto',
                      width: 22,
                      height: 22,
                      marginTop: 10,
                      borderRadius: 11,
                      border: '1px solid rgba(128, 128, 128, 0.5)',
                      background: picked ? '#4d6bfe' : 'transparent',
                      color: '#fff',
                      fontSize: 12,
                      lineHeight: '20px',
                      cursor: 'pointer',
                    }}
                  >
                    {picked ? '✓' : ''}
                  </button>
                  <div style={{ flex: 1, minWidth: 0 }}>{node}</div>
                </div>
              )
            })}
          </div>
        </div>
        {selecting ? (
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '8px 16px',
              borderTop: '1px solid rgba(128, 128, 128, 0.22)',
            }}
          >
            <span style={{ flex: 1, fontSize: 12, opacity: 0.8 }}>
              {t('selectedMessagesCount', { count: selected.size })}
            </span>
            <Button size="s" variant="outlined" onClick={exitMessageSelection}>
              {t('cancel')}
            </Button>
            <Button
              size="s"
              variant="danger"
              disabled={selected.size === 0 || streaming}
              onClick={() => setConfirmDelete(true)}
            >
              {t('delete')}
            </Button>
          </div>
        ) : null}
        {overflowing && !selecting ? (
          <button
            type="button"
            aria-label={atBottom ? t('scrollToTop') : t('scrollToBottom')}
            onClick={atBottom ? jumpToTop : jumpToBottom}
            style={{
              position: 'fixed',
              left: 12,
              bottom: 150,
              zIndex: 20,
              width: 36,
              height: 36,
              borderRadius: 18,
              border: '1px solid rgba(128, 128, 128, 0.35)',
              background: 'rgba(128, 128, 128, 0.14)',
              color: 'inherit',
              fontSize: 16,
              lineHeight: '34px',
              cursor: 'pointer',
              padding: 0,
            }}
          >
            {atBottom ? '↑' : '↓'}
          </button>
        ) : null}
        {confirmDelete ? (
          <Modal
            title={t('deleteSelectedMessagesTitle')}
            onClose={() => setConfirmDelete(false)}
            footer={
              <>
                <Button variant="outlined" onClick={() => setConfirmDelete(false)}>
                  {t('cancel')}
                </Button>
                <Button
                  variant="danger"
                  onClick={() => {
                    const ids = [...selected]
                    setConfirmDelete(false)
                    if (deleteMessages(session.id, ids)) {
                      exitMessageSelection()
                    } else {
                      showToast({ key: 'messagesDeleteFailed', type: 'error' })
                    }
                  }}
                >
                  {t('delete')}
                </Button>
              </>
            }
          >
            {t('deleteSelectedMessagesDescription', { count: selected.size })}
          </Modal>
        ) : null}
        {footer}
      </div>
    </ScrollToBottomContext.Provider>
  )
}
