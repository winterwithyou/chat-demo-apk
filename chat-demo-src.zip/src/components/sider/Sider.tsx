import clsx from 'clsx'
import { useEffect, useMemo, useState } from 'react'
import { useTranslate } from '../../i18n/index.js'
import {
  IconCheckOutline16,
  IconPanelLeftOutline16,
  IconSettingsOutline16,
  NewChatIcon,
} from '../base/icons.js'
import { setSiderCollapsed } from '../../services/settings.js'
import { groupSessions } from '../../services/chat/sessionGroups.js'
import {
  newChat,
  removeSession,
  removeSessions,
  useChatStore,
} from '../../services/chat/store.js'
import type { SessionSummary } from '../../services/chat/types.js'
import { Button } from '../base/Button.js'
import { IconButton } from '../base/IconButton.js'
import { Modal } from '../base/Modal.js'
import { showToast } from '../base/toastState.js'
import { openSettings } from '../settings/settingsDialogState.js'
import { closeMobileSider, useMobileSider } from './mobileSiderState.js'
import { SessionItem } from './SessionItem.js'
import { SessionSearch } from './SessionSearch.js'
import { useBalance } from '../../services/balance.js'
import styles from './Sider.module.css'
import extra from './SiderExtras.module.css'

/** 余额低于该值时高亮提示 */
const LOW_BALANCE_THRESHOLD = 10

/** 展开的侧边栏：名称与收起按钮、开启新对话、按时间分组的会话列表、底部设置；移动端放在抽屉里，收起按钮关闭抽屉 */
export const Sider = ({ mobile = false }: { mobile?: boolean }) => {
  const t = useTranslate()
  const sessions = useChatStore((state) => state.sessions)
  const activeId = useChatStore((state) => state.activeId)
  const [now, setNow] = useState(Date.now)
  const groups = useMemo(() => groupSessions(sessions, now, t), [sessions, now, t])
  const [deleting, setDeleting] = useState<SessionSummary | null>(null)
  const [deletePending, setDeletePending] = useState(false)
  /** 多选模式：整行点击切换选中，底部显示批量删除 */
  const [selectMode, setSelectMode] = useState(false)
  const [selected, setSelected] = useState<ReadonlySet<string>>(() => new Set<string>())
  const [batchPending, setBatchPending] = useState(false)
  const [confirmBatch, setConfirmBatch] = useState(false)
  /** 搜索关键词；非空时用结果列表替换按时间分组的历史列表 */
  const [query, setQuery] = useState('')
  const balance = useBalance()
  const lowBalance =
    balance !== null && Number.parseFloat(balance.total) < LOW_BALANCE_THRESHOLD

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>
    const refresh = () => {
      clearTimeout(timer)
      const time = Date.now()
      setNow(time)
      const midnight = new Date(time).setHours(24, 0, 0, 0)
      timer = setTimeout(refresh, midnight - time)
    }
    const onVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        refresh()
      }
    }
    refresh()
    document.addEventListener('visibilitychange', onVisibilityChange)
    window.addEventListener('focus', refresh)
    return () => {
      clearTimeout(timer)
      document.removeEventListener('visibilitychange', onVisibilityChange)
      window.removeEventListener('focus', refresh)
    }
  }, [])

  const exitSelectMode = () => {
    setSelectMode(false)
    setSelected(new Set<string>())
    setConfirmBatch(false)
  }

  const toggleSelected = (id: string) => {
    setSelected((current) => {
      const next = new Set(current)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }

  const runBatchDelete = async () => {
    const ids = [...selected]
    if (ids.length === 0) {
      return
    }
    setBatchPending(true)
    try {
      const removed = await removeSessions(ids)
      exitSelectMode()
      if (removed < ids.length) {
        showToast({ key: 'sessionDeleteFailed', type: 'error' })
      }
    } finally {
      setBatchPending(false)
    }
  }

  return (
    <div className={clsx(styles.sider, mobile && styles.mobile)}>
      <div className={styles.top}>
        <div className={styles.appName}>{t('appName')}</div>
        <IconButton
          size="m"
          icon={<IconCheckOutline16 />}
          tooltip={t('selectSessions')}
          tooltipPlacement="bottom"
          onClick={() => (selectMode ? exitSelectMode() : setSelectMode(true))}
        />
        <IconButton
          size="m"
          icon={<IconPanelLeftOutline16 />}
          tooltip={t('collapseSiderbarButton')}
          tooltipPlacement="bottom"
          onClick={() => (mobile ? closeMobileSider() : setSiderCollapsed(true))}
        />
      </div>
      <button
        type="button"
        className={styles.newChat}
        onClick={() => {
          newChat()
          closeMobileSider()
        }}
      >
        <span className={styles.newChatIcon}>
          <NewChatIcon />
        </span>
        {t('newChat')}
      </button>
      <div className={styles.listWrap}>
        <div style={{ padding: '0 12px' }}>
          <SessionSearch query={query} onQueryChange={setQuery} onPick={closeMobileSider} />
        </div>
        <div className={styles.list}>
          {query.trim() === ''
            ? groups.map((group) => (
                <div key={group.key} className={styles.section}>
                  <div className={styles.sectionHeader}>{group.label}</div>
                  {group.sessions.map((session) => (
                    <SessionItem
                      key={session.id}
                      session={session}
                      active={session.id === activeId}
                      onDelete={() => setDeleting(session)}
                      selectMode={selectMode}
                      selected={selected.has(session.id)}
                      onToggleSelect={() => toggleSelected(session.id)}
                    />
                  ))}
                </div>
              ))
            : null}
        </div>
      </div>
      <div className={styles.bottom}>
        {balance ? (
          <div
            style={{
              padding: '0 2px 8px',
              fontSize: 11,
              opacity: 0.75,
              color: lowBalance ? '#e5484d' : 'inherit',
            }}
          >
            {t('balanceLabel')}：{balance.currency} {balance.total}
            {lowBalance ? ` · ${t('balanceLowTip')}` : ''}
          </div>
        ) : null}
        {selectMode ? (
          <div className={extra.batchBar}>
            <span className={extra.batchCount}>
              {t('selectedSessionsCount', { count: selected.size })}
            </span>
            <Button
              size="s"
              variant="outlined"
              disabled={batchPending}
              onClick={exitSelectMode}
            >
              {t('cancel')}
            </Button>
            <Button
              size="s"
              variant="danger"
              disabled={batchPending || selected.size === 0}
              onClick={() => setConfirmBatch(true)}
            >
              {t('delete')}
            </Button>
          </div>
        ) : (
          <button
            type="button"
            className={styles.settings}
            onClick={() => openSettings('general')}
          >
            <span className={styles.settingsIcon}>
              <IconSettingsOutline16 />
            </span>
            <span className={styles.settingsLabel}>{t('settings')}</span>
          </button>
        )}
      </div>
      {deleting ? (
        <Modal
          title={t('deleteSessionModalContentTitle')}
          onClose={() => {
            if (!deletePending) {
              setDeleting(null)
            }
          }}
          footer={
            <>
              <Button variant="outlined" disabled={deletePending} onClick={() => setDeleting(null)}>
                {t('cancel')}
              </Button>
              <Button
                variant="danger"
                disabled={deletePending}
                onClick={async () => {
                  setDeletePending(true)
                  try {
                    if (await removeSession(deleting.id)) {
                      setDeleting(null)
                    } else {
                      showToast({ key: 'sessionDeleteFailed', type: 'error' })
                    }
                  } finally {
                    setDeletePending(false)
                  }
                }}
              >
                {t('delete')}
              </Button>
            </>
          }
        >
          {t('deleteSessionWithFilesDescription')}
        </Modal>
      ) : null}
      {confirmBatch ? (
        <Modal
          title={t('deleteSelectedSessionsTitle')}
          onClose={() => {
            if (!batchPending) {
              setConfirmBatch(false)
            }
          }}
          footer={
            <>
              <Button
                variant="outlined"
                disabled={batchPending}
                onClick={() => setConfirmBatch(false)}
              >
                {t('cancel')}
              </Button>
              <Button variant="danger" disabled={batchPending} onClick={() => void runBatchDelete()}>
                {t('delete')}
              </Button>
            </>
          }
        >
          {t('deleteSelectedSessionsDescription', { count: selected.size })}
        </Modal>
      ) : null}
    </div>
  )
}

/** 移动端抽屉：浮在页面上方，点空白区域关闭。 */
export const MobileSider = () => {
  const open = useMobileSider((state) => state.open)
  if (!open) {
    return null
  }
  return (
    <>
      <div className={styles.drawerMask} onClick={closeMobileSider} />
      <div className={styles.drawer}>
        <Sider mobile />
      </div>
    </>
  )
}
