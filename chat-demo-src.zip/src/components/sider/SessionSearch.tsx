import { useEffect, useState } from 'react'
import { useTranslate } from '../../i18n/index.js'
import * as db from '../../services/chat/db.js'
import { selectSession, useChatStore } from '../../services/chat/store.js'
import type { Message } from '../../services/chat/types.js'

/** 一条搜索结果：命中的会话与摘要片段 */
type SearchResult = {
  sessionId: string
  title: string
  snippet: string
}

/** 结果条数上限，避免长会话列表一次渲染过多 */
const RESULT_LIMIT = 30

const messageText = (message: Message): string => {
  if (message.role === 'user') {
    return message.content
  }
  return message.blocks
    .map((block) => (block.type === 'text' ? block.text : ''))
    .filter(Boolean)
    .join('\n')
}

/** 在会话标题与全部消息正文里做不区分大小写的包含匹配。 */
const useSessionSearch = (query: string): { results: SearchResult[]; pending: boolean } => {
  const sessions = useChatStore((state) => state.sessions)
  const [results, setResults] = useState<SearchResult[]>([])
  const [pending, setPending] = useState(false)

  useEffect(() => {
    const keyword = query.trim().toLowerCase()
    if (!keyword) {
      setResults([])
      setPending(false)
      return
    }
    let cancelled = false
    setPending(true)
    void (async () => {
      const found: SearchResult[] = []
      for (const summary of sessions) {
        if (found.length >= RESULT_LIMIT) {
          break
        }
        const title = summary.title || ''
        if (title.toLowerCase().includes(keyword)) {
          found.push({ sessionId: summary.id, title, snippet: '' })
          continue
        }
        const session = await db.loadSession(summary.id)
        if (!session) {
          continue
        }
        const hit = session.messages.map(messageText).find((text) => text.toLowerCase().includes(keyword))
        if (hit === undefined) {
          continue
        }
        const index = hit.toLowerCase().indexOf(keyword)
        const snippet = hit
          .slice(Math.max(0, index - 16), index + 48)
          .replace(/\s+/g, ' ')
          .trim()
        found.push({ sessionId: summary.id, title, snippet })
      }
      if (!cancelled) {
        setResults(found)
        setPending(false)
      }
    })()
    return () => {
      cancelled = true
    }
  }, [query, sessions])

  return { results, pending }
}

/** 侧边栏搜索框：输入即搜会话标题与消息正文，点结果跳转到该会话。 */
export const SessionSearch = ({
  query,
  onQueryChange,
  onPick,
}: {
  query: string
  onQueryChange: (value: string) => void
  onPick: () => void
}) => {
  const t = useTranslate()
  const { results, pending } = useSessionSearch(query)
  const searching = query.trim() !== ''

  return (
    <div style={{ padding: '4px 0 8px' }}>
      <input
        value={query}
        onChange={(event) => onQueryChange(event.target.value)}
        placeholder={t('searchSessionsPlaceholder')}
        style={{
          width: '100%',
          boxSizing: 'border-box',
          padding: '6px 10px',
          fontSize: 12,
          borderRadius: 8,
          border: '1px solid rgba(128, 128, 128, 0.35)',
          background: 'transparent',
          color: 'inherit',
          outline: 'none',
        }}
      />
      {searching ? (
        <div style={{ marginTop: 6 }}>
          {pending ? null : results.length === 0 ? (
            <div style={{ fontSize: 11, opacity: 0.6, padding: '6px 2px' }}>
              {t('searchNoResult')}
            </div>
          ) : (
            results.map((result) => (
              <div
                key={result.sessionId}
                onClick={() => {
                  selectSession(result.sessionId)
                  onQueryChange('')
                  onPick()
                }}
                style={{
                  padding: '6px 6px',
                  borderRadius: 8,
                  cursor: 'pointer',
                  borderBottom: '1px solid rgba(128, 128, 128, 0.14)',
                }}
              >
                <div style={{ fontSize: 13, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {result.title || t('untitledChat')}
                </div>
                {result.snippet ? (
                  <div style={{ fontSize: 11, opacity: 0.65, marginTop: 2, wordBreak: 'break-all' }}>
                    {result.snippet}
                  </div>
                ) : null}
              </div>
            ))
          )}
        </div>
      ) : null}
    </div>
  )
}
