import { translate } from '../../../i18n/index.js'
import { saveExportFile } from '../../exportFile.js'
import { getVisibleMessages } from '../branches.js'
import * as db from '../db.js'
import type { Session } from '../types.js'

const pad = (value: number) => String(value).padStart(2, '0')

/** 文件名里的时间戳：20261121-1330 */
const stamp = (time: number): string => {
  const date = new Date(time)
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}`
}

/** 去掉标题里不能出现在文件名中的字符 */
const safeName = (title: string, time: number): string => {
  const base = title.replace(/[\\/:*?"<>|\s]+/g, '_').slice(0, 40) || 'chat'
  return `${base}-${stamp(time)}.md`
}

/** 把当前选中的分支导出为 Markdown：提问、回答文本与附件名。 */
const buildMarkdown = (session: Session): string => {
  const lines: string[] = [`# ${session.title || translate('untitledChat')}`, '']
  lines.push(`> ${translate('exportedAt')}${new Date().toLocaleString()}`, '')
  for (const message of getVisibleMessages(session)) {
    if (message.role === 'user') {
      lines.push(`## ${translate('exportRoleUser')}`, '')
      if (message.content.trim()) {
        lines.push(message.content.trim(), '')
      }
      if (message.files.length > 0) {
        lines.push(
          `${translate('exportAttachments')}${message.files.map((file) => file.name).join(', ')}`,
          ''
        )
      }
      continue
    }
    const text = message.blocks
      .map((block) => (block.type === 'text' ? block.text : ''))
      .filter((part) => part.trim() !== '')
      .join('\n\n')
    if (!text) {
      continue
    }
    lines.push(`## ${translate('exportRoleAssistant')}`, '', text.trim(), '')
  }
  return lines.join('\n')
}

/** 导出单个会话为 Markdown 文件；会话不存在时返回 false。 */
export const exportSessionMarkdown = async (sessionId: string): Promise<boolean> => {
  const session = await db.loadSession(sessionId)
  if (!session) {
    return false
  }
  const title = session.title || translate('untitledChat')
  await saveExportFile(safeName(title, session.updatedAt), buildMarkdown(session))
  return true
}
