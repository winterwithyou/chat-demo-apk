import { translate } from '../../../i18n/index.js'
import { saveExportFile } from '../../exportFile.js'
import * as db from '../db.js'
import { exportArchive } from './exportArchive.js'

const pad = (value: number) => String(value).padStart(2, '0')

/** 文件名里的时间戳：20261121-1330 */
const stamp = (time: number): string => {
  const date = new Date(time)
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}`
}

/** 去掉标题里不能出现在文件名中的字符 */
const safeName = (title: string, time: number): string => {
  const base = title.replace(/[\\/:*?"<>|\s]+/g, '_').slice(0, 40) || 'chat'
  return `${base}-${stamp(time)}.zip`
}

/**
 * 导出单个会话为与应用同格式的 ZIP 备份包，可再通过「导入」追加回来。
 * 归档只包含该会话及其图片原件。
 */
export const exportSessionArchive = async (sessionId: string): Promise<boolean> => {
  const session = await db.loadSession(sessionId)
  if (!session) {
    return false
  }
  const blob = await exportArchive([session])
  const title = session.title || translate('untitledChat')
  await saveExportFile(safeName(title, session.updatedAt), blob)
  return true
}
