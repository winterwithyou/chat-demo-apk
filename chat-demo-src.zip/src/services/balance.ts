import { useEffect, useState } from 'react'
import { useSettings } from './settings.js'

/** DeepSeek 余额接口返回的单条币种余额 */
export type BalanceInfo = {
  currency: string
  total: string
}

type BalanceResponse = {
  is_available?: boolean
  balance_infos?: BalanceInfo[]
}

/** 读取账户余额；没有权限、接口不可用或网络失败时返回 null。 */
export const fetchBalance = async (apiKey: string): Promise<BalanceInfo | null> => {
  try {
    const response = await fetch(`${__API_ORIGIN__}/user/balance`, {
      headers: { Authorization: `Bearer ${apiKey}` },
    })
    if (!response.ok) {
      return null
    }
    const data = (await response.json()) as BalanceResponse
    return data.balance_infos?.[0] ?? null
  } catch {
    return null
  }
}

/** 当前 API Key 对应的余额；没有 Key 或读取失败时为 null。 */
export const useBalance = (): BalanceInfo | null => {
  const apiKey = useSettings((state) => state.apiKey)
  const [balance, setBalance] = useState<BalanceInfo | null>(null)

  useEffect(() => {
    if (!apiKey) {
      setBalance(null)
      return
    }
    let cancelled = false
    void fetchBalance(apiKey).then((info) => {
      if (!cancelled) {
        setBalance(info)
      }
    })
    return () => {
      cancelled = true
    }
  }, [apiKey])

  return balance
}
