import { Capacitor } from '@capacitor/core'
import { Directory, Filesystem } from '@capacitor/filesystem'
import { Share } from '@capacitor/share'

/** Blob 转 base64（去掉 data: 前缀），Filesystem 写二进制时需要 */
const blobToBase64 = (blob: Blob): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onerror = () => reject(reader.error ?? new Error('read export file failed'))
    reader.onload = () => {
      const result = reader.result
      if (typeof result !== 'string') {
        reject(new Error('unexpected reader result'))
        return
      }
      const comma = result.indexOf(',')
      resolve(comma >= 0 ? result.slice(comma + 1) : result)
    }
    reader.readAsDataURL(blob)
  })

/**
 * 保存导出文件：原生端先写入缓存目录，再弹出系统分享面板（可存到手机、发到微信）；
 * 网页端回退为浏览器下载。
 */
export const saveExportFile = async (fileName: string, data: Blob | string): Promise<void> => {
  const blob =
    typeof data === 'string' ? new Blob([data], { type: 'text/plain;charset=utf-8' }) : data

  if (!Capacitor.isNativePlatform()) {
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = fileName
    link.click()
    setTimeout(() => URL.revokeObjectURL(url), 10_000)
    return
  }

  const result = await Filesystem.writeFile({
    path: fileName,
    data: await blobToBase64(blob),
    directory: Directory.Cache,
  })
  await Share.share({ title: fileName, files: [result.uri], dialogTitle: fileName })
}
